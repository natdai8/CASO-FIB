#include <mach.h>
#include <mach_error.h>
#include <mach/mig_errors.h>
#include <mach/thread_status.h>
#include <mach/processor_info.h>
#include <stdio.h>
#include <stdlib.h>
#include <hurd.h>

int main(int argc, char * argv[]) {

	int res;
	mach_port_t task = pid2task(atoi(argv[1]));
	vm_address_t address = atoi(argv[2]);
   	 vm_size_t size;
    	vm_offset_t data;
   	 mach_msg_type_number_t data_count;
	res = vm_read(task, address, size, &data, &data_count);

	if (res != KERN_SUCCESS) {
      		printf ("Error reading (0x%x), %s \n", res,
        	mach_error_string(res));
        	exit(1);
	}

	for (int i = 0; i < data_count; ++i) printf("byte %d : %x\n", i, ((char*)data)[i]);
}
