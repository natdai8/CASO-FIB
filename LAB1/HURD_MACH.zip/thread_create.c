#include <mach.h>
#include <mach_error.h>
#include <mach/mig_errors.h>
#include <mach/thread_status.h>
#include <mach/processor_info.h>
#include <stdio.h>
#include <stdlib.h>
#include <hurd.h>

void bucle () 
{
	while(1);
}

void printAlgo()
{
	printf("algo");
}

int main(int argc, char * argv[]) {

	int res;
	mach_port_t child_thread;
	res = thread_create (mach_task_self(), &child_thread);

	if (res != KERN_SUCCESS) {
      		printf ("Error creating thread (0x%x), %s \n", res,
	        mach_error_string(res));
      		exit(1);
	}

	struct i386_thread_state state;
	mach_msg_type_number_t oldCount = THREAD_STATE_MAX;
	res = thread_get_state (child_thread, i386_THREAD_STATE, (thread_state_t)&state, &oldCount);

	if (res != KERN_SUCCESS) {
      		printf ("Error getting thread state (0x%x), %s \n", res,
	        mach_error_string(res));
      		exit(1);
	}

	char buff[256];
	state.eip = &buff[4];
	state.uesp = &buff[252];
	res = thread_set_state(child_thread, i386_THREAD_STATE, (thread_state_t)&state, oldCount);

	if (res != KERN_SUCCESS) {
      		printf ("Error setting thread state (0x%x), %s \n", res,
	        mach_error_string(res));
      		exit(1);
	}

	res = thread_resume(child_thread);
	
	if (res != KERN_SUCCESS) {
      		printf ("Error resuming thread (0x%x), %s \n", res,
	        mach_error_string(res));
      		exit(1);
	}

	bucle();
	printAlgo();

}
