#include <mach.h>
#include <mach_error.h>
#include <mach/mig_errors.h>
#include <mach/thread_status.h>
#include <mach/processor_info.h>
#include <stdio.h>
#include <stdlib.h>
#include <hurd.h>

int main(int argc, char * argv[]) {

	int res;
	mach_port_t child_task;
	res = task_create (mach_task_self(), 0, &child_task);

	if (res != KERN_SUCCESS) {
      		printf ("Error creating task (0x%x), %s \n", res,
       		mach_error_string(res));
        	exit(1);
	}

	vm_address_t address = 0x10000000;
   	int size = 4096 * 16;
	res = vm_allocate(child_task, &address, size, 1);

    	if (res != KERN_SUCCESS) {
        	printf ("Error allocating memory (0x%x), %s \n", res,
        	mach_error_string(res));
        	exit(1);
	}

	vm_offset_t offset [4096];
	vm_write(child_task, address, offset, (mach_msg_type_number_t)size);

    	if (res != KERN_SUCCESS) {
        	printf ("Error writing memory (0x%x), %s \n", res,
        	mach_error_string(res));
        	exit(1);
	}

	while(1);
}
