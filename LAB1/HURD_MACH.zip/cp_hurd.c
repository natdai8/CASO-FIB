#include <mach.h>
#include <mach_error.h>
#include <mach/mig_errors.h>
#include <mach/thread_status.h>
#include <mach/processor_info.h>
#include <stdio.h>
#include <stdlib.h>
#include <hurd.h>
#include <hurd/io.h>

int main(int argc, char * argv[]) {

    if (argc != 3) {
        printf("Usage: ./cp_hurd <source_file> <destination_file>");
        exit(1);
    }

    int res;
    mach_port_t task = mach_task_self();
    file_t source_file, destination_file;
    source_file = file_name_lookup(argv[1], O_RDONLY, 0);

    if (source_file == MACH_PORT_NULL) {
      	printf ("Error opening the source file (0x%x), %s \n", source_file,
        mach_error_string(source_file));
        exit(1);
    }

    destination_file = file_name_lookup(argv[2], O_WRONLY, 0);

    if (destination_file == MACH_PORT_NULL) {
      	printf ("Error opening the destination file (0x%x), %s \n", destination_file,
        mach_error_string(destination_file));
        exit(1);
    }

    char buf[4096];
    vm_offset_t offset = 0;
    int nbytes = 256, nread = 0, nwritten = 0;
    
    while (res = io_read(source_file, buf, &nread, offset, nbytes) > 0) {

        if (res != KERN_SUCCESS) {
            printf ("Error reading from source file (0x%x), %s \n", res,
            mach_error_string(res));
            exit(1);
        }

    	if (nread == 0) break;
        
	res = io_write(destination_file, buf, &nwritten, offset, nread);

	if (res != KERN_SUCCESS) {
	    printf("Error writing to destination file (0x%x, %s \n)", res,
            mach_error_string(res));
	    exit(1);
	}

	offset += nread;
    }

    mach_port_deallocate(task, source_file);
    mach_port_deallocate(task, destination_file);
}
